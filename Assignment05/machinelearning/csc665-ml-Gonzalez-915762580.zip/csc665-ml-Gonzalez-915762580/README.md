# Artificial Intelligence - Homework 5
### Name: Jair Gonzalez
### Student ID: 915762580

## Description: Project number 5 of CSC665.  First task was simple, just returning a stored weight vector as a dotproduct object. The next part 
## was just simple doing if else statements for me w = self.run(x) if it was greater than 0 I would return 1. 
## final part was doing a loop over the data set and make updates on examples that are misclassified adn then correct them. 
## this project took approximately 1 and a half hours to complete. 




