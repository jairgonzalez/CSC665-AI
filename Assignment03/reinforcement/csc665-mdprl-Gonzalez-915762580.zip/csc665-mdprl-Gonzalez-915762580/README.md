# Artificial Intelligence - Homework 3
### Name: Jair Gonzalez
### Student ID: 915762580

## Description: Project number 3 of CSC665. Implementing value iteration and Q learning. Within this project we test our agents within a grid world which is essentially a simulated robot controller as well as our pacman.

total time spent on this assignment would be over 6 hours

