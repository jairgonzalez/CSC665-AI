# Artificial Intelligence - Homework 2
### Name: Jair Gonzalez
### Student ID: 915762580

## Description: Assignment consisted of working on 4 areas in MultiAgent.py including Reflex Agent, MiniMax, Expectimax and Evaluation Function 

First area to work on was to implement a evaluation function for our reflex agent that would allow for several useful feedback for our pacmam, I basically monitored for 3 main conditions. First one was checking if the state of pacman was set to stop, next was to check if the ghost x y coordinates matched the x y coordinates of pacman, and the final one was if the current distance to food was farther than the distance of a set variable. Second area is our Min and Max function, for we create a algorithm that can work with any number of ghosts. This aglorithm creates a minimization of possible for a possible loss, and then maximizes for largest possible win. Third area is expectimax is the expectimax, which is another form of the minimax algorithm but instead of depending on the conditions of the game we use a probability.Finally our better Evaluation function was a added for us to make a better implementation than the evaluation function, this time I implemented it with getting returning the values of the food and the current position of pacman.

The time if took for completion of this project was probably over 7 hours I would have to say. 